package em.myapplication.myeconomy.usuario.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;

import em.myapplication.myeconomy.infra.dao.DBHelper;
import em.myapplication.myeconomy.usuario.dominio.Usuario;


public class UsuarioDAO {

//    private Context context;
//    private SQLiteDatabase db;
//    private DBHelper dbHelper;
//    private boolean excluir;
//
//    public boolean isExcluir() {
//        return excluir;
//    }
//
//    public void setExcluir(boolean excluir) {
//        this.excluir = excluir;
//    }
//
//    public UsuarioDAO(Context context){
//        dbHelper = new DBHelper(context);
//    }
//
//    public boolean excluir(){
//        Usuario usuario=new Usuario(context);
//        usuario.setCodigo(-1);
//        DBHelper dbHelper = null;
//        SQLiteDatabase sqLiteDatabase = null;
//        try{
//            dbHelper = new DBHelper(context);
//            sqLiteDatabase = dbHelper.getWritableDatabase();
//            sqLiteDatabase.beginTransaction();
//
//            sqLiteDatabase.delete("usuario","codigo = ?",new String[]{String.valueOf(usuario.getCodigo())});
//
//            excluir = true;
//
//            sqLiteDatabase.setTransactionSuccessful();
//            sqLiteDatabase.endTransaction();
//            return true;
//        }catch (Exception e){
//            e.printStackTrace();
//            sqLiteDatabase.endTransaction();
//            return false;
//        }finally {
//            if (sqLiteDatabase != null)
//                sqLiteDatabase.close();
//            if (dbHelper != null)
//                dbHelper.close();
//        }
//    }
//
//    public boolean salvar(){
//        Usuario usuario=new Usuario(context);
//        DBHelper dbHelper = null;
//        SQLiteDatabase sqLiteDatabase = null;
//        try{
//            dbHelper = new DBHelper(context);
//            sqLiteDatabase = dbHelper.getWritableDatabase();
//            String sql = "";
//            if (usuario.getCodigo() == -1){
//                sql = "INSERT INTO usuario (nome,email,senha) VALUES (?,?,?)";
//            }else{
//                sql = "UPDATE usuario SET nome = ?, email = ?, senha = ? WHERE codigo = ?";
//            }
//            sqLiteDatabase.beginTransaction();
//            SQLiteStatement sqLiteStatement = sqLiteDatabase.compileStatement(sql);
//            sqLiteStatement.clearBindings();
//            sqLiteStatement.bindString(1,usuario.getNome());
//            sqLiteStatement.bindString(2,usuario.getEmail());
//            sqLiteStatement.bindString(3,usuario.getSenha());
//            if (usuario.getCodigo() != -1)
//                sqLiteStatement.bindString(5,String.valueOf(usuario.getCodigo()));
//            sqLiteStatement.executeInsert();
//            sqLiteDatabase.setTransactionSuccessful();
//            sqLiteDatabase.endTransaction();
//            return true;
//        }catch (Exception e){
//            e.printStackTrace();
//            sqLiteDatabase.endTransaction();
//            return false;
//        }finally {
//            if (sqLiteDatabase != null)
//                sqLiteDatabase.close();
//            if (dbHelper != null)
//                dbHelper.close();
//        }
//    }
//
//    public ArrayList<Usuario> getUsuarios(){
//        DBHelper dbHelper = null;
//        SQLiteDatabase sqLiteDatabase = null;
//        Cursor cursor = null;
//        ArrayList<Usuario> usuarios = new ArrayList<>();
//        try{
//            dbHelper = new DBHelper(context);
//            sqLiteDatabase = dbHelper.getReadableDatabase();
//            cursor = sqLiteDatabase.query("usuario",null,null,null,null,null,null);
//            while (cursor.moveToNext()){
//                Usuario usuario = new Usuario(context);
//                usuario.setCodigo(cursor.getInt(cursor.getColumnIndex("codigo")));
//                usuario.setNome(cursor.getString(cursor.getColumnIndex("nome")));
//                usuario.setSenha(cursor.getString(cursor.getColumnIndex("senha")));
//                usuario.setEmail(cursor.getString(cursor.getColumnIndex("email")));
//                usuarios.add(usuario);
//            }
//        }catch (Exception e){
//            e.printStackTrace();
//        }finally {
//            if ((cursor != null) && (!cursor.isClosed()))
//                cursor.close();
//            if (sqLiteDatabase != null)
//                sqLiteDatabase.close();
//            if (dbHelper != null)
//                dbHelper.close();
//        }
//        return usuarios;
//    }
//
//    public void carregaUsuarioPeloCodigo(int codigo){
//        DBHelper dbHelper = null;
//        SQLiteDatabase sqLiteDatabase = null;
//        Cursor cursor = null;
//        try{
//            dbHelper = new DBHelper(context);
//            sqLiteDatabase = dbHelper.getReadableDatabase();
//            Usuario usuario=new Usuario(context);
//            cursor = sqLiteDatabase.query("usuario",null,"codigo = ?",new String[]{String.valueOf(codigo)},null,null,null);
//            excluir = true;
//            while (cursor.moveToNext()){
//                usuario.setCodigo(cursor.getInt(cursor.getColumnIndex("codigo")));
//                usuario.setNome(cursor.getString(cursor.getColumnIndex("nome")));
//                usuario.setSenha(cursor.getString(cursor.getColumnIndex("senha")));
//                usuario.setEmail(cursor.getString(cursor.getColumnIndex("email")));
//                excluir = false;
//            }
//        }catch (Exception e){
//            e.printStackTrace();
//        }finally {
//            if ((cursor != null) && (!cursor.isClosed()))
//                cursor.close();
//            if (sqLiteDatabase != null)
//                sqLiteDatabase.close();
//            if (dbHelper != null)
//                dbHelper.close();
//        }
//    }

}
